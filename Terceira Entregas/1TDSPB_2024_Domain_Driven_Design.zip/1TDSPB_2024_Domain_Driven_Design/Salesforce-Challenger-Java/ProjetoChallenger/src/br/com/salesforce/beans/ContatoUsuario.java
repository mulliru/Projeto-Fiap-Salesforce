package br.com.salesforce.beans;

public class ContatoUsuario {
	
	private String idContato;
	private String nome;
	private String telefoneContato;
	private String emailContato;
	
	public ContatoUsuario() {
		super();
	}
	

	public ContatoUsuario(String idContato, String nome, String telefoneContato, String emailContato) {
		super();
		this.idContato = idContato;
		this.nome = nome;
		this.telefoneContato = telefoneContato;
		this.emailContato = emailContato;
	}








	public String getIdContato() {
		return idContato;
	}


	public void setIdContato(String idContato) {
		this.idContato = idContato;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getTelefoneContato() {
		return telefoneContato;
	}


	public void setTelefoneContato(String telefoneContato) {
		this.telefoneContato = telefoneContato;
	}


	public String getEmailContato() {
		return emailContato;
	}


	public void setEmailContato(String emailContato) {
		this.emailContato = emailContato;
	}


	public String toString(){
		return"\nCodigo: " + idContato + "\nNome: " + nome + "\nTelefone de contato: " + telefoneContato + "\nEmail: " + emailContato;
	}
}
