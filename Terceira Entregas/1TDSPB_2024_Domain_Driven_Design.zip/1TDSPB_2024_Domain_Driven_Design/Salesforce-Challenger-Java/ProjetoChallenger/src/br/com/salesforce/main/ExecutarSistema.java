package br.com.salesforce.main;

import br.com.salesforce.form.DisplayMenu;

public class ExecutarSistema {

	public static void main(String[] args) {
		DisplayMenu display = new DisplayMenu();
		display.exibir();
		
	}

}
