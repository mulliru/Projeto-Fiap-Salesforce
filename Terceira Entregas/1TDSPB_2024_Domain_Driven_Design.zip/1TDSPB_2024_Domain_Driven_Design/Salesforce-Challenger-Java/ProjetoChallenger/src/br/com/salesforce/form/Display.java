package br.com.salesforce.form;

public interface Display {
	
	public void exibir();
}
