package br.com.salesforce.form;

import java.util.Scanner;

import br.com.salesforce.beans.Produto;

public class ProdutoForm {
	public Produto exibirFormulario() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("\n---ENTRADA PRODUTO--");
		System.out.print("Informe o numero do produto: ");
		int numeroProduto  = Integer.parseInt(scanner.nextLine());

		System.out.print("Informe o nome do produto: ");
		String nomeProduto = scanner.nextLine();
		
		System.out.print("Informe o tipo do produto: ");
		String tipoProduto = scanner.nextLine();
		
		System.out.print("Infome o valor do produto: ");
		Double valorProduto = Double.parseDouble(scanner.nextLine());
		
		Produto produto = new Produto();
		
		produto.setNumeroProduto(numeroProduto);
		produto.setNomeProduto(nomeProduto);
		produto.setTipoProduto(tipoProduto);
		produto.setValorProduto(valorProduto);;
		
		return produto;
	}
}
