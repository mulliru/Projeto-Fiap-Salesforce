package br.com.salesforce.beans;

public class EnderecoUsuario {

	private String nacionalidade;
	private String estado;

	public EnderecoUsuario() {
		super();
	}

	public EnderecoUsuario(String nacionalidade, String estado) {
		super();
		this.nacionalidade = nacionalidade;
		this.estado = estado;
	}

	public String getNacionalidade() {
		return nacionalidade;
	}

	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade.toUpperCase();
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado.toUpperCase();
	}

	public String toString() {
		return "\nNacionalidade: " + nacionalidade + "\nEstado: " + estado ;
	}

}
