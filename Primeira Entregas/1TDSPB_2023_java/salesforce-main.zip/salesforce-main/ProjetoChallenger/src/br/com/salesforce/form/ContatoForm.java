package br.com.salesforce.form;

import java.util.Scanner;

import br.com.salesforce.beans.ContatoUsuario;

public class ContatoForm {
	public ContatoUsuario exibirFormulario() {
		
		Scanner scanner = new Scanner(System.in);

		System.out.println("\n\n--CONTATO--");
		System.out.print("Infome o seu nome: ");
		String nome = scanner.nextLine();
		
		System.out.print("Infome seu Telefone: ");
		String telefoneContato = scanner.nextLine();
		
		System.out.print("Infome o Email: ");
		String emailContato = scanner.nextLine();
		
		ContatoUsuario contato = new ContatoUsuario();
		
		contato.setNome(nome);
		contato.setTelefoneContato(telefoneContato);
		contato.setEmailContato(emailContato);
		
		return contato;
	}
}
