package br.com.salesforce.form;

import java.util.Scanner;

import br.com.salesforce.beans.EnderecoUsuario;

public class CadastroEnderecoForm {
	public EnderecoUsuario exirbirFormulario() {
		Scanner scanner = new Scanner(System.in);

		System.out.println("\n---ENTREADA-----\n");
		System.out.print("Infome a sua nacionalidade: ");
		String nacionalidade = scanner.nextLine();

		System.out.print("Infome o seu estado: ");
		String estado = scanner.nextLine();

		EnderecoUsuario endereco = new EnderecoUsuario();

		endereco.setNacionalidade(nacionalidade);
		endereco.setEstado(estado);

		return endereco;

	}

}
