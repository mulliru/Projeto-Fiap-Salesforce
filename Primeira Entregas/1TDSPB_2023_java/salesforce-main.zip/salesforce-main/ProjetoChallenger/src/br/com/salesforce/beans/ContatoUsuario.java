package br.com.salesforce.beans;

public class ContatoUsuario {
	
	private String nome;
	private String telefoneContato;
	private String emailContato;
	
	public ContatoUsuario() {
		super();
	}
	
	public ContatoUsuario(String nome,String telefoneContato, String emailContato) {
		super();
		this.nome = nome;
		this.telefoneContato = telefoneContato;
		this.emailContato = emailContato;
	}


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefoneContato() {
		return telefoneContato;
	}
	public void setTelefoneContato(String telefoneContato) {
		this.telefoneContato = telefoneContato;
	}
	public String getEmailContato() {
		return emailContato;
	}
	public void setEmailContato(String emailContato) {
		this.emailContato = emailContato;
	}
	
	public String toString(){
		return"\nNome: " + nome + "\nTelefone de contato: " + telefoneContato + "\nEmail: " + emailContato;
	}
}
