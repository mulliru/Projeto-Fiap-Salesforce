package br.com.salesforce.beans;

import java.time.LocalDate;
import java.time.Period;

public class CadastroUsuario {

	private String nome;
	private String sobrenome;
	private String cpf;
	private LocalDate nascimento;
	private String telefone;
	private String email;
	private String senha;
	private EnderecoUsuario enderecoUsuario;
	private LoginUsuario loginUsuario;
	
	

	public CadastroUsuario() {
		super();
	}
	
	public CadastroUsuario(String nome, String sobrenome, String cpf, LocalDate nascimento, String telefone,
			String email, String senha, EnderecoUsuario enderecoUsuario, LoginUsuario loginUsuario) {
		super();
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
		this.nascimento = nascimento;
		this.telefone = telefone;
		this.email = email;
		this.senha = senha;
		this.enderecoUsuario = enderecoUsuario;
		this.loginUsuario = loginUsuario;
	}



	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome.toUpperCase();
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome.toUpperCase();
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public LocalDate getNascimento() {
		return nascimento;
	}

	public void setNascimento(LocalDate nascimento) {
		this.nascimento = nascimento;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email.toLowerCase();
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public EnderecoUsuario getEnderecoUsuario() {
		return enderecoUsuario;
	}

	public void setEnderecoUsuario(EnderecoUsuario enderecoUsuario) {
		this.enderecoUsuario = enderecoUsuario;
	}

	public LoginUsuario getLoginUsuario() {
		return loginUsuario;
	}

	public void setLoginUsuario(LoginUsuario loginUsuario) {
		this.loginUsuario = loginUsuario;
	}

	public int getIdade() {
		LocalDate dataAtual = LocalDate.now();
		Period periodo = Period.between(nascimento, dataAtual);
		return periodo.getYears();
	}
	
	public String podeCadastar() {
		String informacao = "Usuario pode ser cadastrado";
		if(getIdade() >= 18) {
		}else{
			informacao = "Usuario menor de 18 anos não pode ser cadastrado";
		}
		return informacao;
	}

	public String toString() {
		return "Nome: " + nome + "\nSobrenome: " + sobrenome + "\nCPF: " + cpf + "\nData de nascimento: " + nascimento
				+ "\nTelefone: " + telefone + "\nEmail: " + email + "\nSenha: " + senha;
	}

}
