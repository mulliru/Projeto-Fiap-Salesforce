package br.com.salesforce.form;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import br.com.salesforce.beans.CadastroUsuario;

public class CadastroUsuarioForm {
	
	public CadastroUsuario exibirFormulario() {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Infome o nome: ");
		String nome = scanner.nextLine();

		System.out.print("Informe o sobrenome: ");
		String sobrenome = scanner.nextLine();

		System.out.print("Infome o CPF: ");
		String cpf = scanner.nextLine();

		System.out.print("Digite a data de nascimento (no formato dd/MM/yyyy): ");
		String nascimentostr = scanner.nextLine();
		LocalDate nascimento = LocalDate.parse(nascimentostr, DateTimeFormatter.ofPattern("dd/MM/yyyy"));

		System.out.print("Informe o Telefone: ");
		String telefone = scanner.nextLine();

		System.out.print("Informe o EMAIL: ");
		String email = scanner.nextLine();

		System.out.print("Informe a SENHA: ");
		String senha = scanner.nextLine();
		
		CadastroUsuario cadastro = new CadastroUsuario();

		// Cadastro
		cadastro.setNome(nome);
		cadastro.setCpf(sobrenome);
		cadastro.setCpf(cpf);
		cadastro.setNascimento(nascimento);
		cadastro.setTelefone(telefone);
		cadastro.setEmail(email);
		cadastro.setSenha(senha);
		
		return cadastro;
		
		
		
	}
	

}
