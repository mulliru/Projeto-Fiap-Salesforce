package br.com.salesforce.main;

import br.com.salesforce.beans.CadastroUsuario;
import br.com.salesforce.beans.ContatoUsuario;
import br.com.salesforce.beans.EnderecoUsuario;
import br.com.salesforce.beans.LoginUsuario;
import br.com.salesforce.beans.Pedido;
import br.com.salesforce.beans.Produto;
import br.com.salesforce.form.CadastroEnderecoForm;
import br.com.salesforce.form.CadastroUsuarioForm;
import br.com.salesforce.form.ContatoForm;
import br.com.salesforce.form.LoginUsuarioForm;
import br.com.salesforce.form.PedidoForm;
import br.com.salesforce.form.ProdutoForm;

public class ExecutarSistema {

	public static void main(String[] args) {

		CadastroUsuarioForm formularioCadastroUsuario = new CadastroUsuarioForm();
		CadastroUsuario cadastro = formularioCadastroUsuario.exibirFormulario();

		CadastroEnderecoForm formularioEnderecoUsuario = new CadastroEnderecoForm();
		EnderecoUsuario endereco = formularioEnderecoUsuario.exirbirFormulario();

		LoginUsuarioForm formularioLoginUsuario = new LoginUsuarioForm();
		LoginUsuario login = formularioLoginUsuario.exibirFormulario();

		PedidoForm formularioPedido = new PedidoForm();
		Pedido pedido = formularioPedido.exibirFormulario();

		ProdutoForm formularioProduto = new ProdutoForm();
		Produto produto = formularioProduto.exibirFormulario();

		ContatoForm formularioContato = new ContatoForm();
		ContatoUsuario contato = formularioContato.exibirFormulario();

		System.out.println("\n\n----IMFORMACOES-------\n" + cadastro.toString() + cadastro.getIdade() + "\n"
				+ cadastro.podeCadastar() + "\n\n--IMFORMACOES-ENDERECO--\n" + endereco.toString()
				+ "\n\n---IMFORMAÇOES LOGIN\n" + login.toString() + "\n\n--IMFORMAÇOES-PEDIDO--\n" + pedido.toString()
				+ "\n\n--INFORMACOES-PRODUTO--" + produto.toString() + "\n\n--INFORMACAO-CONTATO--\n"
				+ contato.toString());
	}

}
